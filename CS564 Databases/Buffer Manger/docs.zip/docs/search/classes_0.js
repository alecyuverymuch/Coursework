var searchData=
[
  ['badbufferexception',['BadBufferException',['../classbadgerdb_1_1_bad_buffer_exception.html',1,'badgerdb']]],
  ['badgerdbexception',['BadgerDbException',['../classbadgerdb_1_1_badger_db_exception.html',1,'badgerdb']]],
  ['bufdesc',['BufDesc',['../classbadgerdb_1_1_buf_desc.html',1,'badgerdb']]],
  ['bufferexceededexception',['BufferExceededException',['../classbadgerdb_1_1_buffer_exceeded_exception.html',1,'badgerdb']]],
  ['bufhashtbl',['BufHashTbl',['../classbadgerdb_1_1_buf_hash_tbl.html',1,'badgerdb']]],
  ['bufmgr',['BufMgr',['../classbadgerdb_1_1_buf_mgr.html',1,'badgerdb']]],
  ['bufstats',['BufStats',['../structbadgerdb_1_1_buf_stats.html',1,'badgerdb']]]
];
