var searchData=
[
  ['next_5fpage_5fnumber',['next_page_number',['../classbadgerdb_1_1_page.html#a8050c219873e6b1d51aec2adbea8a507',1,'badgerdb::Page']]]
];
